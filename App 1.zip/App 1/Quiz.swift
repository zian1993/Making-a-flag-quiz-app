//
//  Quiz.swift
//  App 1
//
//  Created by Hassan Khan on 9/19/18.
//  Copyright © 2018 Hassan Khan. All rights reserved.
//
import Foundation
import UIKit


public class Quiz
{
    
    private var randarray : [Int]
    private var randnum: Int
    private var totalimages : Int
    private var numofrandnum : Int
    
    private var questionprefix : String
    private var answerprefix : String
    
    private var imageload: UIImage!
    private var questionarray : [UIImage]
    private var answerarray : [UIImage]
    private var answerarrayfix : [UIImage]
    
    //Class Initializer
    public init (_ QuestionArrayprefix : String, _ AnswerArrayPrefix : String, _ TotalImages : Int)
    {
        //Initializing all the private data types
        
        randarray = [Int]()
        questionarray = [UIImage]()
        answerarray = [UIImage]()
        answerarrayfix = [UIImage]()
        
        randnum = 0
        numofrandnum = 0
        
        totalimages = TotalImages
        
        questionprefix = QuestionArrayprefix
        answerprefix = AnswerArrayPrefix
    }
    
    //Random number generator method
    public func rand_generator (_ Numofnum : Int)
    {
        //Setting class variable to the users choice of 
        //number of random numbers that the user wants to generate
    
        numofrandnum = Numofnum
        
        //Creating the random numbers to use for the images to load as question and answer.
        for i in 0...(numofrandnum-1)
        {
            randnum = (Int(arc4random())%(totalimages-1))
            
            //Checking to make sure that the random number generated is not repeated.
            if (randarray.count>=1)
            {
            for a in 0...((randarray.count)-1)
            {
                while(randnum == randarray[a]){
                    randnum = (Int(arc4random())%(totalimages-1))}
                
                }}
            
            randarray.append(randnum)
        }
    }
    
    public func question_images_generator () -> [UIImage]?
    {
        //Creating the image arrays of questions based on the randomly generated numbers.
        for b in 0...(numofrandnum-1)
        {
            let q = questionprefix+"\(randarray[b])"+".png"
            imageload = UIImage(named: q)!
            questionarray.append(imageload)
            
            //If the image cannot be loaded, return nil
            if (imageload == nil)
            {return nil}
        }
        return questionarray
    }
    
    public func answer_images_generator () -> [UIImage]?
    {
        //Creating the image arrays of answers based on the randomly generated numbers.
        for c in 0...(numofrandnum-1)
        {
            let q = answerprefix+"\(randarray[c])"+".png"
            imageload = UIImage(named: q)!
            answerarray.append(imageload)
            
            //If the image cannot be loaded, return nil
            if (imageload == nil)
            {return nil}
        }
        return answerarray
    }
    
    public func answer_images_fix (_ images : [UIImage]!) -> [UIImage]!
    {
        
        for i in 0...images.count-1
        {
            //Loading the blank image 7 times
            imageload = UIImage(named: "blank(1).png")
            answerarrayfix.append(imageload)
            answerarrayfix.append(imageload)
            answerarrayfix.append(imageload)
            answerarrayfix.append(imageload)
            answerarrayfix.append(imageload)
            answerarrayfix.append(imageload)
            answerarrayfix.append(imageload)
            
            //Now loading the real flag image
            answerarrayfix.append(answerarray[i])
            answerarrayfix.append(answerarray[i])
            answerarrayfix.append(answerarray[i])
            
        }
        return answerarrayfix
    }
}
