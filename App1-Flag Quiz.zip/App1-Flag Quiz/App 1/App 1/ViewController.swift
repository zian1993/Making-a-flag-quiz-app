//
//  ViewController.swift
//  App 1
//
//  Created by Hassan Khan on 9/19/18.
//  Copyright © 2018 Hassan Khan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    //Declaring the interface builder variables
    @IBOutlet private var questionimage: UIImageView!
    @IBOutlet private var answerimage: UIImageView!
    @IBOutlet private var textdisplay : UILabel!
    
    //Declaring the image array variables to be used
    private var questionarray : [UIImage]?
    private var answerarray : [UIImage]?
    private var answerarrayfix : [UIImage]
    
    //Declaring the private text variable to be used
    private var textman : String
    
    //Declaring the quiz variable that we will use to
    //create the animations
    private var quizguy : Quiz
    
    required init?(coder aDecoder: NSCoder)
    {
        questionarray = [UIImage]()
        answerarray = [UIImage]()
        answerarrayfix = [UIImage]()
        
        textman = ""
        
        quizguy = Quiz("image", "pic", 222)
        
        //self.textdisplay.text = "Welcome to the game, my friend!"
        
        super.init(coder: aDecoder)
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //Initiating the random number generator in my quiz
        //object
        quizguy.rand_generator(10)
        
        //Getting the question images from the quiz objct
        questionarray = quizguy.question_images_generator()!
        
        //If a nil is returned from the function, display 
        //the error message
        for a in 0...questionarray!.count-1
        {
        if (questionarray?[a] == nil)
        {
            textman = "Unable to run quiz my friend!"
            textdisplay.text = textman
        }
        }
        
        //Getting the answer images from the quiz object
        answerarray = quizguy.answer_images_generator()!
        
        //If a nil is returned from the function, display
        //the error message
        for h in 0...answerarray!.count-1
        {
            if (answerarray?[h] == nil)
            {
                textman = "Unable to run quiz my friend!"
                textdisplay.text = textman
            }
        }
        
        //Fixing up the answers array to get the answer array with
        //the blank images, to be run in the animation
        answerarrayfix = quizguy.answer_images_fix(answerarray)
        
        //Okay, now finally setting up the animation
        
        //Setting up and starting the question and answer images array
        //animation
        
            questionimage.animationImages = questionarray
            answerimage.animationImages = answerarrayfix
        
            questionimage.animationDuration = TimeInterval(100)
            answerimage.animationDuration = TimeInterval(100)
        
            questionimage.animationRepeatCount = 0
            answerimage.animationRepeatCount = 0
        
            questionimage.startAnimating()
            answerimage.startAnimating()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}
